import React from "react";
function Footer(){
    return(
        <>
        <section class="container-fluid footer_section">
    <p>
      &copy; <span id="displayYear"></span> All Rights Reserved By
      <a href="https://html.design/">Free Html Templates</a>
    </p>
  </section>
        </>
    )
}export default Footer;