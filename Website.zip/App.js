import './App.css';
import Home from './Home';
import Services from './Services';
import Layout from './Layout';
import {BrowserRouter, Routes, Route} from "react-router-dom";
function App() {
  return (
    <BrowserRouter>
    <Routes>
        <Route>
           <Route path="/" element={<Layout />}/>
           <Route index element={<Home />} />
           <Route path="Home" element={<Home />}/>
           <Route path="Services" element={<Services />}/>
        </Route>
    </Routes>
    </BrowserRouter>
  );
}
export default App;
